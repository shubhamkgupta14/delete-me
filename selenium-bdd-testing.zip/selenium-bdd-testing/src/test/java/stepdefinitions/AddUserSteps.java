package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static locators.AddUserLocators.*;
import static locators.LoginLocators.button_signup;
import static utils.Constants.driver;

public class AddUserSteps {
    @Given("user is on sign up page")
    public void userIsOnSignUpPage() {
        driver.findElement(button_signup).click();
    }

    @When("user enters details as firstname {string} lastname {string} email {string} and password {string}")
    public void userEntersDetailsAsFirstnameLastnameEmailAndPassword(
            String fName, String lName, String email, String password) {
        driver.findElement(textField_firstName).sendKeys(fName);
        driver.findElement(textField_lastName).sendKeys(lName);
        driver.findElement(textField_email).sendKeys(email);
        driver.findElement(textField_password).sendKeys(password);
    }

    @Then("user click on signup submit button")
    public void userClickOnSignupSubmitButton() {
        driver.findElement(button_submit).click();
    }
}
