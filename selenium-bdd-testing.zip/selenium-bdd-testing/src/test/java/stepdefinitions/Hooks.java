package stepdefinitions;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import org.openqa.selenium.chrome.ChromeDriver;

import java.time.Duration;

import static utils.Constants.*;

public class Hooks {


    @BeforeAll
    public static void launch_webSite() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(URL);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_TIMEOUT));
    }

    @AfterAll
    public static void close_browser() {
        driver.close();
    }
}
