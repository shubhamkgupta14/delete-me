package stepdefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

import static locators.AddUserLocators.button_logout;
import static locators.ContactListLocators.label_header;
import static locators.LoginLocators.*;
import static utils.Constants.driver;

public class LoginSteps {
    @Given("user is on login page")
    public void userIsOnLoginPage() {
    }

    @When("user enters credentials as email {string} and password {string}")
    public void userEntersCredentialsAsEmailAndPassword(String email, String password) {
        driver.findElement(textField_email).sendKeys(email);
        driver.findElement(textField_password).sendKeys(password);
    }

    @Then("user click on login submit button")
    public void userClickOnLoginSubmitButton() {
        driver.findElement(button_submit).click();
    }

    @And("verifies contact list page with header {string}")
    public void verifiesContactListPageWithHeader(String header) {
        String actualHeader = driver.findElement(label_header).getText();
//        Assert.assertEquals(actualHeader, "Contact List");

        // verify logout button is displayed
        Assert.assertTrue(driver.findElement(button_logout).isDisplayed());
    }

    @And("click on Logout button")
    public void clickOnLogoutButton() {
        driver.findElement(button_logout).click();
    }

    @And("verify user navigate to login page")
    public void verifyUserNavigateToLoginPage() {
        String actualHeader = driver.findElement(label_header).getText();
        Assert.assertEquals(actualHeader, "Contact List App");

        Assert.assertTrue(driver.findElement(button_signup).isDisplayed());
    }
}
