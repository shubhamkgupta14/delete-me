package locators;

import org.openqa.selenium.By;

public class AddUserLocators {

    public static By textField_firstName = By.id("firstName");
    public static By textField_lastName = By.id("lastName");
    public static By textField_email = By.id("email");
    public static By textField_password = By.id("password");
    public static By button_submit = By.id("submit");
    public static By button_logout = By.id("logout");
}
