package locators;

import org.openqa.selenium.By;

public class ContactListLocators {

    public static By label_header = By.tagName("h1");
}
