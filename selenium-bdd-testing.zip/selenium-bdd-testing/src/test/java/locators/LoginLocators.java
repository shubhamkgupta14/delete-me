package locators;

import org.openqa.selenium.By;

public class LoginLocators {

    public static By textField_email = By.id("email");
    public static By textField_password = By.id("password");
    public static By button_submit = By.id("submit");
    public static By button_signup = By.id("signup");
}
