package test;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.time.Duration;

import static utils.Constants.*;

public class Hooks {


    @BeforeSuite
    public void launch_webSite() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(URL);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(IMPLICIT_TIMEOUT));
    }

    @AfterSuite
    public void close_browser() {
        driver.close();
    }
}
