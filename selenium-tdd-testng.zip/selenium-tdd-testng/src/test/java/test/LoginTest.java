package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import static locators.ContactListLocators.label_header;
import static locators.AddUserLocators.button_logout;
import static locators.LoginLocators.*;
import static utils.Constants.driver;

public class LoginTest {

    @Test(priority = 1)
    public void enter_user_credentials_to_login() {
        driver.findElement(textField_email).sendKeys("name@name.com");
        driver.findElement(textField_password).sendKeys("1234567");
    }

    @Test(priority = 2)
    public void click_on_login_submit_button() {
        driver.findElement(button_submit).click();
    }

    @Test(priority = 3)
    public void verify_contact_list_page() {
        String actualHeader = driver.findElement(label_header).getText();
//        Assert.assertEquals(actualHeader, "Contact List");

        // verify logout button is displayed
        Assert.assertTrue(driver.findElement(button_logout).isDisplayed());
    }

    @Test(priority = 4)
    public void logout_user() {
        driver.findElement(button_logout).click();
    }

    @Test(priority = 5)
    public void verify_navigate_to_login_page() {
        String actualHeader = driver.findElement(label_header).getText();
        Assert.assertEquals(actualHeader, "Contact List App");

        // verify logout button is displayed
        Assert.assertTrue(driver.findElement(button_signup).isDisplayed());
    }




}
