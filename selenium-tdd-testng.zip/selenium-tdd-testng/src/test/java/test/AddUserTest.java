package test;

import org.testng.Assert;
import org.testng.annotations.Test;

import static locators.AddUserLocators.*;
import static locators.LoginLocators.button_signup;
import static locators.ContactListLocators.label_header;
import static utils.Constants.driver;

public class AddUserTest {

    @Test(priority = 1)
    public void click_on_signup_button() {
        driver.findElement(button_signup).click();
    }

    @Test(priority = 2)
    public void enter_user_details_to_signup() {
        driver.findElement(textField_firstName).sendKeys("");
        driver.findElement(textField_lastName).sendKeys("");
        driver.findElement(textField_email).sendKeys("");
        driver.findElement(textField_password).sendKeys("1234567");
    }

    @Test(priority = 3)
    public void click_on_signup_submit_button() {
        driver.findElement(button_submit).click();
    }

    @Test(priority = 4)
    public void verify_contact_list_page() {
        String actualHeader = driver.findElement(label_header).getText();
        Assert.assertEquals(actualHeader, "Contact List");

        // verify logout button is displayed
        Assert.assertTrue(driver.findElement(button_logout).isDisplayed());

    }




}
