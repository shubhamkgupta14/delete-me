package utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Constants {

    public static WebDriver driver = null;
    public static final String URL = "https://thinking-tester-contact-list.herokuapp.com/";
    public static final long IMPLICIT_TIMEOUT = 20;
}
